import sys
import telnetlib
import re
from collections import namedtuple #used for making structure 
from astropy.table import Table
import threading
import net_tools as network
import time
import os
import fcntl

def process():
	Host ='192.168.0.50'
	admin ='admin'
        f =open("telnet.txt","w+")
        f.write("")
        f.close
        print("This is telnet update file")
        try:
            tn= telnetlib.Telnet(Host,23,3)
	    tn.open(Host)
            tn.write(admin+"\n")
        except:
            print("Not able to login into telnet host")
            sys.exit()
        try:
            tn.read_until("Password:")
            tn.write("admin"+"\n")
            tn.read_until("DGS-1210-10P> ")
        except:
            print("Login or password error")
        try:
	    tn.write("debug info" + "\n")
	    while True:
		try:
		    f =open("telnet.txt" ,"a")
		    fcntl.lockf(f,fcntl.LOCK_EX) ## lock  the file 
		    while True:
			r = tn.read_until("DGS-1210-10P> ",timeout =.2)
			#print(r.strip())
			if r.strip() =='':
			    break
			f.write(r)
			tn.write(" ")
		    fcntl.flock(f,fcntl.LOCK_UN) ##unlock the file 
		    f.close()
		    break
		except:
		    time.sleep(0.02)
        except:
                try:
                    x = tn.read_until("DGS-1210-10P> ")
                except:
                    print("Not able to get debug info")

def start():
	while True:
	    process()
	    time.sleep(0.25)

	 
if __name__== '__main__':
	start()

